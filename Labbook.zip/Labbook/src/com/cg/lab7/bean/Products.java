package com.cg.lab7.bean;
import java.util.*;
import java.lang.*;

public class Products {
	public ArrayList Sortpro(ArrayList l1)
	{
		Collections.sort(l1);
		return l1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Products s = new Products();
		ArrayList l2 = new ArrayList();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of elements");
		int n = sc.nextInt();
		for(int i =0;i<=n;i++)
		{
			l2.add(sc.nextLine());
		}
		
				
				l2= s.Sortpro(l2);
				System.out.println(l2);

	}

}
