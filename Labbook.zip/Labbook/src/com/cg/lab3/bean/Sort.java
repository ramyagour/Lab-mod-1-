package com.cg.lab3.bean;
import java.lang.*;
import java.util.*;

public class Sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		String temp;
		System.out.println("enter array of strings");
		String[] name = new String[5];
		Scanner sc = new Scanner(System.in);
		for( i=0;i<5;i++)
		{
			name[i]= sc.nextLine();
		}
		for(i=0;i<5;i++)
		{
			for(j=1;j<5;j++)
			{
				if(name[i].compareTo(name[j])<0)
				{
					
					temp =name[i];
					name[i]=name[j];
					name[j]=temp;
				}
			}
		}
		System.out.println("sorted list is");
		for(i=0;i<5;i++)
		{
			System.out.println(name[i]+",");
		}
		sc.close();

	}

}
