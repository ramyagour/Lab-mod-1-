package com.cg.lab1.bean;

public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
