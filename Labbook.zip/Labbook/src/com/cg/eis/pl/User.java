package com.cg.eis.pl;
import com.cg.eis.Exception.*;
import com.cg.eis.service.service;

public class User {

	public static void main(String[] args)throws EmployeeException {
		// TODO Auto-generated method stub
		service s = new service();
		s.getDetails();
		System.out.println(s.inssch());
		s.displaydetails();
	
		

	}

}
