package com.cg.eis.service;

public interface EmployeeService {
	public void getDetails();
	public String inssch();
	public void displaydetails();
	

}
