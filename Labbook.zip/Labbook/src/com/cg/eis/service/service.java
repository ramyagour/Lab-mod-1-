package com.cg.eis.service;

import com.cg.eis.Exception.*;
import com.cg.eis.bean.Employee;
 
import java.util.*;


public  class service implements EmployeeService{
	Employee e;

	@Override
	public void getDetails()
	{
		
		Scanner sc = new Scanner(System.in);
		String des = sc.next();
		String name = sc.next();
		int id =sc.nextInt();
		double salary = sc.nextDouble();
		try
		{
			if(salary<3000) {
				throw new EmployeeException(salary);
			}
		}
		catch(EmployeeException e1)
		{
			System.out.println(e1);
		}
		e = new Employee(id,name,salary,des);
		sc.close();
	}
	@Override
	public String inssch()
	{
		if((e.getSalary())>5000 && (e.getSalary())<20000 && e.getDes().equals("System Associate"))
			return "Scheme C";
		else if((e.getSalary())>=20000 && (e.getSalary())<40000 && e.getDes().equals("Programmer"))
			return "Scheme B";
		else if((e.getSalary())>=40000 && e.getDes().equals("Manager"))
			return "Scheme A";
		else if((e.getSalary())<5000 && e.getDes().equals("Clerk"))
			return "No scheme";
		else
				return "null";
			
	}
	
@Override
public void displaydetails()
{
	
	System.out.println("employee id is"+e.getId()+",name is"+e.getName()+",salary is"+e.getSalary()+",designation is"+e.getDes());
}
}
