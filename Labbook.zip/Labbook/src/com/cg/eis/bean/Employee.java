package com.cg.eis.bean;

public class Employee {
	private int id;
	private String name;
	private double salary;
	private String des;
	private String insurancesch;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int id, String name, double salary, String des) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.des = des;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	public String getInsurancesch() {
		return insurancesch;
	}
	public void setInsurancesch(String insurancesch) {
		this.insurancesch = insurancesch;
	}
		

}
