package com.cg.lab6.bean;
import java.util.*;
import java.lang.Exception;

 class CheckExp extends Exception {
	public CheckExp(String s)
	{
		super(s);
	}
 }
	public class Exp{
		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Scanner sc = new Scanner(System.in);
			String s1 = sc.nextLine();
			String s2 = sc.nextLine();
			if(s1.equals(" ") && s2.equals(" "))
			{
				throw new CheckExp("first name and last name cannot be null");
			}
			else
			{
				System.out.println("correct");
			}
			
		}
		catch(CheckExp e)
		{
			System.out.println("caught");
			System.out.println(e.getMessage());
		}

	}

}
