package com.cg.lab4.bean;

public class SavingAccount extends Account {
	private final float minbalance=500;
	@Override
	public void withdraw(double amt)
	{
		if(getBalance()<minbalance)
			System.out.println("invalid ");
		else
			setBalance(getBalance()-amt);
	
	}
	
	

}
