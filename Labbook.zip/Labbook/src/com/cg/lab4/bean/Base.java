package com.cg.lab4.bean;
import java.util.Random;

public class Base {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r = new Random();
Person p1= new Person("SMITH",45);
Person p2= new Person("karly",34);
/*Account a1 =new Account(r.nextLong(),2000,p1);
Account a2 = new Account(r.nextLong(),3000,p2);*/
SavingAccount a1= new SavingAccount();
CurrentAccount a2 = new CurrentAccount();
a1.deposit(2000);
a2.withdraw(2000);
System.out.println("Balance of Smith Account is"+a1.getBalance());
System.out.println("Balance of Karly Account is"+a2.getBalance());
/*System.out.println(a1);
System.out.println(a2);*/


	}

	
}
