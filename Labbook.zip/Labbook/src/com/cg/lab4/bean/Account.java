package com.cg.lab4.bean;

public abstract class Account extends Person{
	private long accno;
	private double balance;
	Person accHolder;
	public abstract void withdraw(double s); 
		
	
	
	

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(String name, float age) {
		super(name, age);
		// TODO Auto-generated constructor stub
	}
	public Account( long accno, double balance, Person accHolder) {
	
		this.accno = accno;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void deposit(double amt)
	{
		
		balance = balance + amt;
		
		
	}
	/*public void withdraw(double amt)
	{
		if(balance==0)
			System.out.println("amount cannot be withdrawn");
		else
		
			balance = balance - amt;
			
	}*/
	@Override
	public String toString() {
		return "Account [accno=" + accno + ", balance=" + balance + ", accHolder=" + accHolder.getName() + "]";
	}
	
	
	

}
