package com.cg.lab11pract.question1;

//public class LambdaExpression implements IPower {
	
	public abstract class LambdaExpression implements  IPower {
		public static void main(String[] args) {
			IPower p =(double x,double y)->{double m=Math.pow(x,y); System.out.println(m); return m;};
			p.power(2.0,2.0);
			
		}

	}


