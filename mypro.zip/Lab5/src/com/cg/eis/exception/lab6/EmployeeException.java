package com.cg.eis.exception.lab6;

public class EmployeeException extends Exception{
	private double sal;
	public EmployeeException(double s)
	{
		sal=s;
	}
	public String toString()
	{
		return sal +"is less than 3000";
	}
	

}
