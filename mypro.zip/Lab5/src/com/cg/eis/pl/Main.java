package com.cg.eis.pl;
import com.cg.eis.exception.lab6.*;
import com.cg.eis.service.Service;

public class Main  {

	public static void main(String[] args)throws EmployeeException {
		// TODO Auto-generated method stub
		
	     Service s=new Service();
	     s.getDetails();
	     s.findInsuranceScheme();
	     s.DisplayDetails();

	}

}
