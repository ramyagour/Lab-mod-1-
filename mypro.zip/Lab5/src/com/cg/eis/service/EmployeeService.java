package com.cg.eis.service;

public interface EmployeeService {
	public void getDetails();
	public String findInsuranceScheme();
	public void DisplayDetails();

}
