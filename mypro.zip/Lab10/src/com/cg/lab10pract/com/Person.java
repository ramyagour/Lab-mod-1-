package com.cg.lab10pract.com;

public class Person {
	private String firstName;
	private String lastName;
	private String gender;
	
public String getFirstName() {
		return firstName;
	}


public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

public String getLastName() {
		return lastName;
	}


public void setLastName(String lastName) {
		this.lastName = lastName;
	}

public void setGender(String gender) {
	this.gender = gender;
}
public String getGender() {
		return gender;
	}}

