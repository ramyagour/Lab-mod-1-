package com.cg.lab4.bean;

public class CurrentAccount extends Account {

	private float overdraft;

	public float getOverdraft() {
		return overdraft;
	}

	public void setOverdraft(float overdraft) 
	{
		this.overdraft = overdraft;
	}
	public boolean printfalse()
	{
	return false;
	}
	public boolean printtrue()
	{
		return true;
	}
	@Override
	public void withdraw(double amt)
	{
		if(getBalance()<overdraft)
			printfalse();
		else
			printtrue();
	
	}
}


