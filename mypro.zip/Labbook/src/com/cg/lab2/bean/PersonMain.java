package com.cg.lab2.bean;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("divya","bharathi",Gender.F,"7890765432");
		p1.display();
		

	}

}
