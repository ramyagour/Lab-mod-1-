package com.cg.lab3.bean;
import java.util.*;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class validate {

	public  boolean Valid(String s1)
	{
		String u = "_job$";
		Pattern p = Pattern.compile(u);
		Matcher matcher = p.matcher(s1);
		if(matcher.find()&&(s1.length()>=8))
			return true;
		else
			return false;
		
		
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean res;
		validate v= new validate();
		Scanner sc= new Scanner(System.in);
		System.out.println("enter name");
		String s= sc.nextLine();
		res= v. Valid(s);
		if(res)
			System.out.println("true");
		else
			System.out.println("false");
		sc.close();
		

	}

}
