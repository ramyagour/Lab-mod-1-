package com.cg.lab3.bean;

import java.util.Scanner;
import java.lang.*;

public class Stringoption {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1;
		StringBuilder s2 = new StringBuilder();
		StringBuilder s3 = new StringBuilder();
		int choice;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string");
		s1 = sc.nextLine();
		System.out.println("enter the choice");
		System.out.println("1.Add the string to itself");
		System.out.println("2.Remove odd positions with#");
		System.out.println("3.Remove duplicates");
		System.out.println("4.Change odd characters to upper case");
		choice = sc.nextInt();
		switch(choice)
		{
		case 1:
			s1 = s1+""+s1;
			System.out.println(s1);
			break;
		case 2:
			for(int i = 1;i<s1.length();i++)
			{
				if(s1.charAt(i)%2!=0)
				{
					s1=s1.substring(0,i-1)+"#"+s1.substring(i,s1.length());
				}
				System.out.println(s1);
			}
			break;
		case 3:
			for(int i = 1;i<s1.length();i++)
			{
				char ch = s1.charAt(i);
				int index = s1.indexOf(ch,i+1);
				if(index==-1)
				{
					s2.append(ch);
				}
				
			}
			System.out.println(s2);
			
		
		break;
		case 4:
			for(int i=1;i<s1.length();i++)
			{
				char ch = s1.charAt(i);
				if(s1.charAt(i)%2!=0)
				{
					ch = Character.toUpperCase(ch);
				}
				s3.append(ch);
			}
			System.out.println(s3);
			break;
			default: 
				System.out.println("wrong choice");
		}

	}

}
