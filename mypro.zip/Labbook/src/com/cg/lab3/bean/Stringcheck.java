package com.cg.lab3.bean;
import java.util.Scanner;

public class Stringcheck {
	public boolean check(String s)
	{
		boolean ans = true;
		char ch;
		for(int i = 0;i<s.length();i++)
		{
			ch = s.charAt(i);
			
				for(int j=i+1;j<s.length();j++)
					
				{
				
					char ch1= s.charAt(j);
					if((Character.valueOf(ch)).compareTo(Character.valueOf(ch1))>0)
					{
						 ans = false;
					}
				}
		
			
	}
		return ans;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Stringcheck c = new Stringcheck();
		String s1;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string");
		s1 = sc.nextLine();
		
		 boolean var=c.check(s1);
		 if(var==true)
			 System.out.println("positive");
		 else
			 System.out.println("negative");
		 
			 		
		

	}

}
