package com.cg.lab3.bean;
import java.time.*;
import java.util.Scanner;
import java.lang.*;

public class Zone {
	public void acceptof(String id)
	{
		if(id.equals(ZoneId.of(id).toString()))
System.out.println(ZonedDateTime.now(ZoneId.of(id)));
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Zone z = new Zone();
		System.out.println("enter zone name");
		String s1;
		Scanner sc = new Scanner(System.in);
		s1 = sc.nextLine();
		z.acceptof(s1);
		sc.close();
		
		
		
	}

}
