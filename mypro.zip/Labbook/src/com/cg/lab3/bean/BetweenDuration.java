package com.cg.lab3.bean;
import java.lang.*;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class BetweenDuration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter first date in dd/MM/yyyy format:");
		String input  = scanner.nextLine();
				LocalDate d2 = LocalDate.parse(input,formatter);

	
		
		System.out.print("Enter second date in dd/MM/yyyy format:");
		String input1  = scanner.nextLine();
				LocalDate d3 = LocalDate.parse(input1,formatter);


	
	
		Period p1 = d2.until(d3);
		System.out.println("days are:"+p1.getDays());
		System.out.println("months are:"+p1.getMonths());
		
		System.out.println("years are:"+p1.getYears());
		
		

	}

}
