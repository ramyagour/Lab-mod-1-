package com.cg.lab3.bean;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Warantee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		System.out.println("enter the date of purchase dd/mm/yyyy");
		
		String s1 =sc.nextLine();
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		System.out.println("enter expiry date in months and years");
		int months = sc.nextInt();
		int year = sc.nextInt();
		LocalDate d1 = LocalDate.parse(s1, fmt);
	System.out.println("purchase date"+d1);
	LocalDate d2 =d1.plusMonths(months);
	LocalDate d3 = d2.plusYears(year);
	System.out.println("expiry date"+d3);
	sc.close();
	


		

	}

}
