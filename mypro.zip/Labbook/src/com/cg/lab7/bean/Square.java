package com.cg.lab7.bean;
import java.util.*;
import java.lang.*;

public class Square {
	public static HashMap getSquare(int[] a1)
	{
		HashMap<Integer , Integer> m2 = new HashMap<Integer , Integer>();
		for(int n: a1)
		{
			m2.put(n , n*n);
		}
		return m2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	int n =sc.nextInt();
	int a[] = new int[n];
	for(int i = 0;i<n;i++)
	{
		a[i]=sc.nextInt();
	}
	HashMap<Integer , Integer> m = getSquare(a);
	Iterator<Integer> i = m.keySet().iterator();
	while(i.hasNext())
	{
		Integer key = i.next();
		System.out.println(key+","+m.get(key));
	}
	
	
		
		
		
		

	}

}
