package com.cg.lab7.bean;
import java.util.*;
import java.lang.*;

public class Remove {
	public List removeElements(List l3, List l4)
	{
		
		  l3.removeAll(l4);
		return l3;
				
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Remove r = new Remove();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of elements");
		int n =sc.nextInt();
	
	
		System.out.println("enter string elements for first list");
		List<String> l1 = new ArrayList<String>();
		List<String> l2 = new ArrayList<String>();
		for(int i =0;i<=n;i++)
		{
			l1.add(sc.nextLine());
		}
		System.out.println("enter string elemts of second list");
		for(int i =0;i<=n;i++)
		{
			l2.add(sc.nextLine());
		}
		
		 l1= r.removeElements(l1,l2);
		 System.out.println(l1);
	}

}
