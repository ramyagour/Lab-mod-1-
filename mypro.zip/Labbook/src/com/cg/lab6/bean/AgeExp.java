package com.cg.lab6.bean;
import java.util.*;
import java.lang.*;
	
	class AgeException extends Exception {
	private int age;
	AgeException(int a)
	{
	age = a; 
	}
	public String toString() 
	{
	return " age should be above 15";
	}
	}
	class emp{
	String name;
	int age;
	void getDetails() throws AgeException{
	System.out.println("Enter your name:");
	Scanner sc=new Scanner(System.in);
	name=sc.next();
	System.out.println("Enter your age:");
	age=sc.nextInt();
	if (age<15)
	throw new AgeException(age);
	}}
	class AgeExp{
	public static void main(String args[]) {
	try {
	emp e=new emp();
	e.getDetails();
	}
	catch (AgeException e) 
	{
	System.out.println( e); 
	}
}
	}
