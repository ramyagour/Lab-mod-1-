package com.cg.lab7pr.bean;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Fileprogram {

public static void main(String[] args) {
	FileInputStream fis;
	FileOutputStream fos;
	try{
		fis = new  FileInputStream("C:\\Users\\SHIVATRI\\Workspace\\Lab8\\src\\shiv.txt");
		fos = new  FileOutputStream("C:\\Users\\SHIVATRI\\Workspace\\Lab8\\src\\yashi.txt");
	    CopyDatathread obj =new CopyDatathread(fis,fos);
	}
	catch(FileNotFoundException e) {
		e.printStackTrace();
	}
}
	
}
