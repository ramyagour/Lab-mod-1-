package com.cg.lab7pr.bean;


public class TimerMain {
	
public static void main(String[] args) {
		

	    TimerThread tt = new TimerThread();
		Thread t = new Thread(tt);
		t.start();

}
}
