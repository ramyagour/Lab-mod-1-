package com.cg.lab7pr.bean;
import java.util.*;
public class TimerThread implements Runnable{
	public void run()
	{
		
		System.out.println("Timer starts at"+new Date());
		while(true) {
		try
		{
			Thread.sleep(10000);
		}
		catch(InterruptedException e)
        {
	          e.printStackTrace();
         }
		System.out.println("Timer Refresh at every 10 sec is:"+new Date());
		}
             
	}}


